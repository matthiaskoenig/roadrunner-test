
import tellurian as te

# Example of using roarunner to get the stoiciometry matrix 
r = te.loada ('''
      -> S1; v1;
      S1 -> S2; v2;
      S2 -> ; v3;
      S3 -> S1; v4;
      S3 -> S2; v5;
      -> S3; v6;
''')

print r.getFullStoichiometryMatrix()
