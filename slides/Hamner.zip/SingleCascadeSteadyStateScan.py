
import tellurium as te
import numpy

# Simple protein phosphorylation cycle. Steady state concentation
# of the phosphorylated protein is plotted as a funtion of the cycle
# kinase. In addition, the plot is repeated for various values of Km.

r = te.loada ('''
   S1 -> S2; k1*S1/(Km1 + S1);
   S2 -> S1; k2*S2/(Km2 + S2);
   
   k1 = 0.1; k2 = 0.4; S1 = 10; S2 = 0;
   Km1 = 0.1; Km2 = 0.1;  
''')

r.conservedMoietyAnalysis = True

te.setHold (True)
for i in range (1,8):
  numbers = linspace (0.1, 1.2, 200)
  result = numpy.empty ([0,2])
  for value in numbers:
      r.model['k1'] = value
      r.steadyState()
      row = numpy.array ([value, r.model.S2])
      result = numpy.vstack ((result, row))
  te.plotArray (result)
  r.model.k1 = 0.1
  r.model.Km1 = r.model.Km1 + 0.5;
  r.model.Km2 = r.model.Km2 + 0.5;

