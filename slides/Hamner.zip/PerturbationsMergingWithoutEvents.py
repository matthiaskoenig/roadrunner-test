import tellurium as te
import numpy

# Example of merging multiple simulations. In between simulations
# a parameter is changed.

r = te.loada ('''
    # Model Definition
    v1: $Xo -> S1;  k1*Xo;
    v2: S1 -> $w;   k2*S1;

    # Initialize constants 
    k1 = 1; k2 = 1; S1 = 15; Xo = 1;
''')

# Time course simulation
m1 = r.simulate (0, 15, 100, ["Time","S1"]);
r.model.k1 = r.model.k1 * 6;
m2 = r.simulate (15, 40, 100, ["Time","S1"]);
r.model.k1 = r.model.k1 / 6;
m3 = r.simulate (40, 60, 100, ["Time","S1"]);

m = numpy.vstack ((m1, m2, m3)); # Merge data
r.plot (m)
