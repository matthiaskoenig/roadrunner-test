
# Time Course Parameter Scan
# Do 5 simulations on a simple model, for each simulation
# a parameter, k1 is changed. The script merges the data together
# and plots the merged array on to one plot. The alternative is
# is to use the setHold method and to plot each graph individually.

import tellurium as te
import numpy

r = te.loada ('''
    J1: $X0 -> S1; k1*X0;
    J2: S1 -> $X1; k2*S1;

    X0 = 1.0; S1 = 0.0; X1 = 0.0;
    k1 = 0.4; k2 = 2.3;
''')  
  
  
m = r.simulate (0, 4, 100, ["Time", "S1"])
for i in range (0,4):
    r.model.k1 = r.model.k1 + 0.1 
    r.reset()
    m = numpy.hstack ((m, r.simulate (0, 4, 100, ['S1'])))

# MUST use plotArray to plot merged data
te.plotArray (m)
