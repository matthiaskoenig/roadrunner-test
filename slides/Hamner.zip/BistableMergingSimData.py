
# Example showing how to to multiple time course 
# simulations, merging the data and plotting it onto
# one platting surface. Alternative is to use setHold()

# Model is a bistable system, simulations start with different
# initial conditions resulting in different steady states reached.

import tellurium as te

r = te.loada ('''
     $Xo -> S1; 1 + Xo*(32+(S1/0.75)^3.2)/(1 +(S1/4.3)^3.2);
     S1 -> $X1; k1*S1;

Xo = 0.09; X1 = 0.0;
S1 = 0.5; k1 = 3.2;
''')

initValue = 0.05
m = r.simulate (0, 4, 100, ["Time", "S1"])
for i in range (0,12):
    r.model.S1 = initValue
    initValue = initValue + 1
    m = numpy.hstack ((m, r.simulate (0, 4, 100, ['S1'])))

te.plotArray (m)