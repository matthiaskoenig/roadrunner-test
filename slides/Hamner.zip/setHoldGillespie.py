import tellurium as te
import numpy
import matplotlib.pyplot as plt


# Using setHold to compare to simulaton runs. In tihs case one
# simulation is a determinsitic run and the second is a stochastic
# simulation.

r = te.loada ('''
     v1: $Xo -> S1;  k1*Xo;
     v2: S1 -> $w;   k2*S1;

     //initialize.  Deterministic process.
     k1 = 1; k2 = 1; S1 = 20; Xo = 1;
''')

m1 = r.simulate (0,20,100);

# Stochastic process
r.resetToOrigin()
m2 = r.gillespie (0, 20, 100, ['time', 'S1'])

# plot all the results together
te.setHold (True)
te.plotArray (m1)
te.plotArray (m2)


